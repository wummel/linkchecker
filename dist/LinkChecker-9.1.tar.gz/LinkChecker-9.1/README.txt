Install documentation is at doc/install.txt
Usage documentation is at doc/html/index.txt or execute
linkchecker --help
